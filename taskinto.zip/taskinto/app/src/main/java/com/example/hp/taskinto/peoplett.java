package com.example.hp.taskinto;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by Priya on 22-03-2017.
 */
public class peoplett extends Fragment {

    EditText e1,e2,e3,e4,e5,e6,e7,e8;

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.peoplet, container, false);
            e1=(EditText)rootView.findViewById(R.id.editText1);
            e2=(EditText)rootView.findViewById(R.id.editText2);
            e3=(EditText)rootView.findViewById(R.id.editText3);
            e4=(EditText)rootView.findViewById(R.id.editText4);
            e5=(EditText)rootView.findViewById(R.id.editText5);
            e6=(EditText)rootView.findViewById(R.id.editText6);
            e7=(EditText)rootView.findViewById(R.id.editText7);
            e8=(EditText)rootView.findViewById(R.id.editText10);



            e1.setText("Male");
            e2.setText("28.05.1997");
            e3.setText("B +ve");
            e4.setText("Indian");
            e5.setText("Tamil, English, Kannada");
            e6.setText("9750509716");
            e8.setText("L130,TNHB Colony,"+"\n"+"Nethajipuram,N.K.Palyam,"+"\n"+"Coimbatore");
            e7.setText("kavin280597@gmail.com");

            return rootView;

        }
}
