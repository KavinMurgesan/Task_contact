package com.example.hp.taskinto;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.support.v4.app.Fragment;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by Priya on 22-03-2017.
 */
public class contacttt extends Fragment {
    EditText e2;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.contactt, container, false);
        e2=(EditText)rootView.findViewById(R.id.editText10);
        e2.setText("kavin280597@gmail.com");

        return rootView;
    }
}
