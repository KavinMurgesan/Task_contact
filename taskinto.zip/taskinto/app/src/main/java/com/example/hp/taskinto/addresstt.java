package com.example.hp.taskinto;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by Priya on 22-03-2017.
 */
public class addresstt extends Fragment {
    EditText e2;
    TextView e1;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.addresst, container, false);
        e2=(EditText)rootView.findViewById(R.id.editText9);

        e2.setText("L130,TNHB Colony,"+"\n"+"Nethajipuram,N.K.Palyam,"+"\n"+"Coimbatore");

        return rootView;
    }
}
